# Chord Anatomy — analysis specification

All functions are pure. Input: `notes: &[u8]` (MIDI, sorted ascending, unique, len ≥ 2) and `Options { spelling, ratio_limit, a4, timbre, tuning }`.

The model is heuristic: the weights below are design choices, not established psychoacoustic constants. The Rust port must reproduce the prototype's outputs for the test vectors at the end.

## 1. Pitch basics
- `pc(m) = m mod 12`, `octave(m) = m/12 − 1` (MIDI 60 = C4).
- Spelling tables:
  - flats: `C D♭ D E♭ E F G♭ G A♭ A B♭ B`
  - sharps: `C C♯ D D♯ E F F♯ G G♯ A A♯ B`
- `f_et(m) = a4 · 2^((m−69)/12)`.
- Interval names for semitone distance d:
  - d < 12: `P1 m2 M2 m3 M3 P4 TT P5 m6 M6 m7 M7`
  - 12–24: `P8 m9 M9 m10 M10 P11 A11 P12 m13 M13 m14 M14 P15`
  - d > 24: `{simple}+{d/12}oct`

## 2. Just ratios and periodicity
Ratio tables by interval class 0..11:
- 5-limit: `1/1 16/15 9/8 6/5 5/4 4/3 45/32 3/2 8/5 5/3 9/5 15/8`
- 7-limit: the same, except ic6 = `7/5` and ic10 = `7/4`

`ratio(d) = table[d mod 12] · 2^(⌊d/12⌋)`, reduced by gcd.

For the voicing, relative to the bass:
1. `r_i = p_i/q_i = ratio(notes[i] − notes[0])`
2. `L = lcm(q_i)`, `a_i = p_i · L / q_i`, `g = gcd(a_i)`, `h_i = a_i / g`

The integers `h_i` are the chord's **harmonic numbers**; display them as `h_0 : h_1 : …`.

- `P = h_0`: bass cycles per chord period.
- `f_bass = f_et(notes[0])`, `f0 = f_bass / P` (common fundamental), `T = P / f_bass` seconds.
- Just frequencies: `f_just_i = f_bass · r_i`. Deviation: `cents_i = 1200 · log2(f_et_i / f_just_i)`.

Use u64 for the intermediate values; the numbers can grow large with 45/32 at wide spans.

## 3. Root readings
For every candidate root `R ∈ 0..12`, let `rel = { (pc − R) mod 12 : pc ∈ pcs }` and `has(i) = i ∈ rel`.

**Frame**
- `P5 = has(7)`, `hasSev = has(11) || has(10)`
- `third`, taking the first rule that matches:
  - `M` if has(4)
  - `m` if has(3)
  - `sus4` if has(5)
  - `sus2` if !hasSev && has(2)
  - otherwise `no3`
- `dim = third==m && has(6) && !P5`; `aug = third==M && has(8) && !P5`
- `sev`:
  - `maj` if has(11)
  - else `dom` if has(10)
  - else `dim` if dim && has(9)
  - else none

**Degree labels**, assigned in this order (each ic is labelled only once):
| ic | label |
|---|---|
| 0 | R |
| third | 3 / ♭3 / 4 / 2 |
| 7 | 5 (if P5) |
| 6 | ♭5 (if dim) |
| 8 | ♯5 (if aug) |
| sev | 7 (maj, ic11) · ♭7 (dom, ic10) · ♭♭7 (dim, ic9) |
| 1 | ♭9 → alt |
| 2 | 9 → nat |
| 3 | ♯9 → alt |
| 5 | 11 → nat |
| 6 | ♯11 → alt if P5 or sev; otherwise ♭5 → alt |
| 8 | ♭13 → alt if sev; otherwise ♭6 → alt |
| 9 | 13 → nat if sev; otherwise 6 → nat |
| 10 | ♭7 → alt (when maj7 is also present) |

`altList = (aug && sev ? ["♯5"] : []) ++ alts`

**Symbol**
1. Start with the root name and `hi = max(7, nat ≥ 9)` when sev ∈ {maj, dom}; otherwise hi = 7.
2. Add the quality:
   - dim: `°7` | `ø7` (sev dom) | `°(maj7)` | `°`
   - else, with third m, add `m`, then:
     - maj: `maj{hi}`, or `m(maj{hi})` for a minor third
     - dom: `{hi}`
     - no seventh: `+` if aug, then `6/9` | `6` | `add9`, then `add11`
3. Then, in order:
   - `sus4` / `sus2`
   - alterations: concatenated with a seventh (`7♯5♯9`), in parentheses without one (`m(♭6)`)
   - `(no3)`
   - `/Bass` when the bass pc ≠ R

**Score**
```
s  = (rootPresent ? 3 : −1.5)
   + (R == bassPc ? 2 : 0)
   + (third ∈ {M,m} ? 2 : third == no3 ? −2.5 : −0.5)
   + (P5 ? 1 : (dim||aug) ? 0.3 : 0)
   + (sev ? 0.8 : 0)
   − 0.4·|nat| − 0.9·|altList|
```
Sort the 12 readings by score, descending. For display, `prob_k = softmax(0.8·score)` over all 12. Best reading = the first.

## 4. Roughness (Sethares 1993, after Plomp–Levelt)
```
d(f1,f2,a1,a2) = min(a1,a2) · (e^(−3.51·s·Δf) − e^(−5.75·s·Δf)),
s = 0.24 / (0.0207·min(f1,f2) + 18.96)
```
- Partials: sine = `[(f,1)]`; harmonic = `[(k·f, 0.88^(k−1)) for k in 1..=6]`.
- `pairRough(f1,f2) = Σ over partials of both notes d(·)`.
- Normalize: `r_ij = clamp(pairRough(f_i,f_j) / pairRough(f_et(60), f_et(61)), 0, 1)`.
- The frequencies used follow the tuning mode.

## 5. Character axes (all clamped to 0..1)
Definitions:
- `pairs`: all i<j with `d = notes[j] − notes[i]`
- `fifthFrame`: any pair with d mod 12 = 7
- `rel`: the best reading's rel set
- `cross = has(3) && has(4)`; `b9dom = has(1) && has(4)`

| axis | formula |
|---|---|
| tension | `1 − exp(−0.9 · Σ r_ij)` |
| harshness | Sum per pair: ic∈{1,11}: d=1→1.0, d=13→0.75, d=11→0.55, else 0.35; ic=6→0.25; d=2→0.3. Then `/1.6 · (fifthFrame ? 1.2 : 1)` |
| ambiguity | `1.1 · prob[1]/prob[0]` (0 if one pc) |
| complexity | `0.4·clamp(log2 P / 7) + 0.25·clamp(alts/3) + 0.15·clamp((|pcs|−3)/4) + 0.1·ambiguity + (!fifthFrame && tension>0.3 ? 0.15 : 0)` |
| brightness | `0.5 + mean(BRIGHT[ic] for ic∈rel, ic≠0)/2.4 + 0.25·(meanMidi − 60)/24`, where `BRIGHT = [0,−1.6,0.4,−1.2,1.3,−0.2,0.8,0.1,−1.3,0.9,−0.5,1.2]` |
| stability | `0.3 + 0.25·fifthFrame + 0.2·(best.R==bassPc) + 0.1·rootPresent − 0.35·tension − 0.15·ambiguity + 0.15·(P ≤ 6)` |
| aggression | `0.45·cross + 0.3·harshness + 0.25·tension + 0.25·b9dom` |

- `valence = clamp(0.6·brightness + 0.4·stability − 0.25·harshness)`
- `arousal = clamp(0.5·tension + 0.3·aggression + 0.2·complexity)`

## 6. Character tags
Tags are evaluated against the best reading; each has a weight. In the explanations, `nm(i)` is the name of pc `(R+i) mod 12`. Sort by weight and show at most 5.

| word | weight | condition | explanation template |
|---|---|---|---|
| aggressive | 1.0 | cross or b9dom | cross: "Major 3rd ({nm4}) against ♯9 ({nm3}): one scale degree in two colours at once, a cross-relation a semitone apart." · b9: "♭9 ({nm1}) over a major-3rd dominant: the root is shadowed a semitone above." |
| harsh | 0.95 | aggressive && has(7) | "The pure 5th ({nm0}–{nm7}) keeps the frame stable, so the clash is exposed rather than blended." |
| complex | 0.95 | aggressive && !has(7) && has(8) | "The ♯5 ({nm8}) replaces the pure 5th. With no stable frame the clash reads as layered and unresolved." |
| grinding | 0.85 | any pair d = 1 | "{a}–{b} sit a semitone apart in the same register: near-maximal roughness." |
| ambiguous | 0.8 | ambiguity > 0.55 | "Reads almost equally as {name0} and {name1}; the ear can hear either root." |
| dark | 0.7 | third m && has(8) && !sev | "Minor 3rd plus ♭6 ({nm8}): both are lowered neighbours, the darkest pairing over a minor frame." |
| lush | 0.7 | sev maj && third M && !cross | "Major 7th ({nm11}) sits a semitone under the octave; the friction stays soft because the triad beneath is consonant." |
| driving | 0.65 | has(4) && has(10) | "Tritone between 3 ({nm4}) and ♭7 ({nm10}) pulls inward toward resolution." |
| luminous | 0.6 | deg[6] == ♯11 | "♯11 ({nm6}) raises the 4th, removing its friction with the 3rd." |
| suspended | 0.6 | third sus4/sus2 | "No 3rd: the chord withholds major or minor." |
| open | 0.6 | n≥3, all adjacent steps ∈ {5,6} | "Stacked 4ths: no triadic centre, evenly spaced and modern." |
| unstable | 0.7 | n≥3, all adjacent steps = 3 | "Stacked minor 3rds divide the octave symmetrically; every note could be the root." |
| fused | 0.5 | P ≤ 6 | "Low periodicity: the notes line up as harmonics {h}, heard almost as one tone-colour." |
| cloudy | 0.5 | P ≥ 40 (else-branch of fused) | "Long common period ({P} bass cycles): the summed wave takes a long time to repeat." |
| bright | 0.4 | no tags yet && third M && P5 | "Major 3rd over a pure 5th: the reference consonance of the major triad." |
| somber | 0.4 | no tags yet && third m && P5 | "Minor 3rd over a pure 5th: stable, but shaded." |

The header summary is the first two words joined with " and ", with the first letter capitalized.

## 7. Waveform
- `span = min(T · window, 0.25 s)`.
- Lane i: `y = sin(2π f_i t)`; sum: `Σ y_i / n`. All phases are 0 at t = 0.
- Period markers at `k·T` for `k·T ≤ span`.

## 8. Test vectors (5-limit, A4 = 440, flats, Just, 6 partials)
| voicing | h ratio | P | T | top readings (score) |
|---|---|---|---|---|
| C3 G3 A♭3 E♭4 `[48,55,56,63]` | 10:15:16:24 | 10 | 76.45 ms | Cm(♭6) 7.1 · A♭maj7/C 6.8 · E♭6add11/C 4.2 · Fm9/C 1.9 (rootless) · … · D♭maj9♯11(no3)/C −3.5 |
| C7♯9 `[48,52,55,58,63]` | 20:25:30:36:48 | 20 | 152.9 ms | C7♯9 7.9 |
| C7♯9♯5 `[48,52,56,58,63]` | 20:25:32:36:48 | 20 | 152.9 ms | C7♯5♯9 6.3 |
| C major `[48,52,55]` | 4:5:6 | 4 | 30.58 ms | C 8.0 · Em(♭6)/C 4.1 · Am7/C 2.3 |

Expected tags:
- C7♯9: aggressive, harsh, driving
- C7♯9♯5: aggressive, complex, driving
- C–G–A♭–E♭: grinding and ambiguous, followed by dark
- C major: fused

Roughness spot check: for G3–A♭3 in the default voicing, the matrix shows r = 1.00 (clamped).

Known limitation: low-ranked readings can produce awkward symbols, such as `A°(maj7)♭7/C` or `E♭6sus4(♭9)/C`. The UI shows only the top 5, so these rarely appear. Improving the symbol builder (spelling enharmonics, treating conflicting sevenths) is a good follow-up.

Recommended unit tests: symbol builder for every preset, harmonic numbers, score ordering, the parser (`"C G Ab Eb"` → `[48,55,56,63]`), and the tag sets above.
