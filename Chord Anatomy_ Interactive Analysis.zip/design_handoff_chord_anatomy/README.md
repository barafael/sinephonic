# Handoff: Chord Anatomy (chord analysis tool)

## Overview
Chord Anatomy is a single-screen tool for analyzing a chord voicing. The user enters notes on a keyboard or as text. The app then shows:

- Every plausible root reading, ranked by fit. C–G–A♭–E♭, for example, reads as Cm(♭6), A♭maj7/C, Fm9/C (rootless) or D♭maj9♯11(no3)/C.
- The interval of each note above the bass, and its function under the selected reading.
- A matrix of every note pair, with the interval name, its just ratio and a roughness value.
- Character words ("aggressive", "harsh", "complex"…), each explained by the interval that causes it, plus 7 numeric axes and a valence × arousal map.
- Each note as a sine wave plus the summed waveform, with the chord's harmonic ratio, common fundamental and period.

Target: a **Dioxus** app (Rust). The algorithms are specified in `ANALYSIS.md`. Write them as a pure Rust crate with no UI dependencies so the web and desktop builds can share it.

## About the design files
`prototype/Chord Anatomy.dc.html` is a **design reference built in HTML**. It is a working prototype of the intended look and behaviour, not production code. To view it, open it in a browser; `support.js` must sit next to it. Rebuild it in Dioxus with idiomatic Rust: signals, components and `rsx!`. Port the analysis logic from `ANALYSIS.md`. The JS inside the prototype's `<script data-dc-script>` block is the executable reference, and the Rust port must reproduce its outputs (see the test vectors).

## Fidelity
**High-fidelity.** Colours, typography, spacing and copy are final. Recreate them as specified below.

## Recommended Dioxus structure
```
chord-anatomy/
  crates/
    chord-core/          # pure Rust, no_std-friendly, fully unit-tested
      src/pitch.rs       # Midi, PitchClass, spelling, note parsing
      src/ratio.rs       # just ratio tables, gcd/lcm, periodicity
      src/reading.rs     # root readings + chord symbol builder + scoring
      src/roughness.rs   # Sethares model
      src/character.rs   # axes, tags, valence/arousal
      src/lib.rs         # analyze(notes, &Options) -> Analysis
    chord-ui/            # Dioxus app (web + desktop)
      src/main.rs
      src/components/{header,keyboard,note_input,presets,readings,
                      interval_table,matrix,character,va_map,waveform,segmented}.rs
      src/audio.rs       # web: web-sys AudioContext; desktop: cpal/rodio
      assets/main.css    # tokens as CSS custom properties
```
- Use a global `Signal<AppState>` (or separate signals) and derive `Analysis` with `use_memo(move || analyze(&notes(), &opts()))`.
- **Waveform:** render it as SVG `<path d=…>` built in Rust. SVG works on web and desktop without a canvas. About 2 points per horizontal px is enough, so build `d` strings for the plot width (default 1200 user units, `preserveAspectRatio="none"`, `vector-effect: non-scaling-stroke`). The HTML prototype uses `<canvas>`, but SVG is the recommended implementation.
- **Audio:** on web, use `web-sys` (`AudioContext`, `OscillatorNode`, `PeriodicWave`, `GainNode`); on desktop, use `cpal` with a simple additive synth. Either can sit behind a trait: `trait Synth { fn play(&self, freqs:&[f64], arpeggio:bool, timbre:Timbre); }`.

## Screen: Chord Anatomy (single page)
The page is a column with `max-width: 1440px`, centred. Padding is `40px clamp(16px,4vw,56px) 96px`. Sections are separated by a `56px` gap. Background is `#F5F3EE`.

Every section header has the same pattern: a row with `gap:12px` and baseline alignment, 11px mono uppercase text with `letter-spacing:.14em`. It holds the number (`#6B665E`), then the title (`#1D1B18`), then a flexible 1px rule (`#D6D0C4`), then optional right-hand hint text (`#6B665E`, normal case, `letter-spacing:0`).

### Header
- A flex row with wrap and `space-between`, aligned to the bottom. It has a `1px solid #1D1B18` bottom border and `22px` bottom padding.
- Left column, `gap:8px`:
  - Eyebrow text "Chord anatomy — voicing analysis" (11px mono uppercase, .14em, `#6B665E`).
  - Chord name: the best reading's symbol, in Source Serif 4 at `clamp(44px,6.5vw,80px)`, line-height 1, `letter-spacing:-.01em`.
  - Notes line, e.g. "C3 – G3 – A♭3 – E♭4" (13px mono, `#6B665E`).
- Right column, aligned right, `gap:12px`:
  - Summary: the first two tags joined with " and ", first letter capitalized, e.g. "Grinding and ambiguous". Source Serif 4 italic, 26px.
  - **Play** button: filled with the accent, white text.
  - **Arpeggiate** button: outlined in 1px ink, transparent; hover `#EBE6DC`.
  - Both buttons use `padding 8px 16px` and `radius 2px`.

### 01 Voicing
Hint text: "click keys to toggle · C2–C6".
- **Keyboard:** MIDI 36–84, which is 29 white keys. The container is 136px tall with a `1px #BDB6A8` left border.
  - White keys are `flex:1` with a `1px #BDB6A8` border (no left border) and bottom radius 3px. Fill is `#FBFAF7`; active keys are the accent. Every C carries a label ("C2"…"C6") at the bottom: 10px mono, `#9A9488`, white on active keys.
  - Black keys are absolutely positioned. `left = ((idx+1)/29 − 0.3/29)·100%`, where idx is the index of the white key directly below; width is `0.6/29·100%` and height is 62%. Fill is `#1D1B18` (active: accent) with a 1px ink border.
- **Row below** (wrap, `gap:12px`):
  - Text input: `flex:1 1 240px`, 15px mono, `padding 9px 12px`, `1px #1D1B18` border, background `#FBFAF7`, placeholder "C3 G3 Ab3 Eb4". It parses on Enter and on blur.
  - Preset chips: 12px, `padding 6px 10px`, `1px #BDB6A8` border, `nowrap`. The active chip is ink-filled with `#F5F3EE` text. Presets in order:
    - C–G–A♭–E♭ `[48,55,56,63]`
    - C7♯9 `[48,52,55,58,63]`
    - C7♯9♯5 `[48,52,56,58,63]`
    - Cmaj7 `[48,52,55,59]`
    - C major `[48,52,55]`
    - C minor `[48,51,55]`
    - C7♭9 `[48,52,55,58,61]`
    - Quartal `[50,55,60,65]`
    - Cluster `[60,61,62]`
  - A "clear" text link: `#6B665E`, underlined.

With fewer than 2 notes, show only "Select two or more notes to analyze." (Source Serif 22px, `#6B665E`) and hide sections 02–06.

### Analysis grid
Sections 02–05 sit in a grid: `grid-template-columns: repeat(auto-fit, minmax(min(100%,520px),1fr))`, gap `56px 48px`. Section 06 spans the full width below it.

### 02 Readings
- Shows the top 5 of the 12 root readings. Each row is a grid of `minmax(0,1fr) 132px`, gap `8px 16px`, padding `12px 14px`, radius 2px.
  - The selected row has background `#EBE6DC`; hover shows the same colour.
  - Clicking a row selects that reading, which relabels section 03.
- Name: Source Serif 26px, line-height 1.1.
- Probability: a 4px bar (track `#E2DDD2`, fill accent) scaled so that the top reading fills 100%, followed by the percentage (38px wide, right-aligned, tabular numerals).
- Row 2 spans both columns: for each distinct pitch class, a dot (8px ink circle), the note name and the muted degree (e.g. "C ♭3"). Right-aligned sub text:
  - "root in bass" when the root is the bass note
  - "root inside · C in bass" when the root is present but not in the bass
  - "rootless · implied F" when the root is absent
- Footnote (muted, max 60ch): "Each of the 12 pitch classes is tried as root. Fit rises when the root is present or in the bass and a clear 3rd, 5th and 7th exist; it falls with alterations, a missing 3rd or a missing root. Click a reading to relabel the intervals."

### 03 Intervals
Hint text: "functions as {selected name}".
- A 6-column grid: `84px 64px minmax(0,1fr) 72px 76px 76px`, min-width 540px, scrolls horizontally when narrow.
- Header row: 11px muted, 1px ink bottom rule. Columns: Note · Degree · Above bass · Just · TET−just · Hz.
- Rows run highest note first, with a `1px #E2DDD2` rule and `10px` vertical padding:
  - Note: 10px dot plus the note name with octave.
  - Degree: Source Serif 17px.
  - Above bass: interval name plus " · N st" (muted). The bass row says "bass".
  - Just: the ratio p/q.
  - TET−just: cents with a sign, e.g. "−13.7¢" (muted).
  - Hz: shows the frequency for the current tuning mode, to 1 decimal.

### 04 Inter-relations
- Caption row: "Upper: interval + roughness · Lower: just ratio" (muted) on the left, a "tone model" segmented toggle (sine | 6 partials) on the right.
- **Matrix:** a grid with columns `56px repeat(n, minmax(0,96px))`, gap 2px, cells 56px tall, radius 2px.
  - Header row: an empty corner, then note names (13px medium).
  - Row headers: `#EBE6DC` background.
  - Diagonal cells: "·" on `#ECE8E0`.
  - **Upper triangle** (column j > row i): the interval name from note i up to note j (15px medium) plus "r 0.00" (10px, 75% opacity). Background is `oklch(0.97−0.35r  0.02+0.12r  35)`; text is white when r > 0.55, otherwise ink.
  - **Lower triangle:** the just ratio (12px muted), transparent background.
- Legend: "smooth" [220px gradient from `oklch(.97 .02 35)` to `oklch(.62 .14 35)`] "rough"; right-aligned "Sethares/Plomp–Levelt, relative to C4–D♭4".

### 05 Character
- **Tags** (up to 5): a grid of `130px minmax(0,1fr)` with a 1px `#E2DDD2` bottom rule. The word is in Source Serif italic 21px; the reason is 13px mono `#4A463F`.
- Below, a 2-column auto-fit (min 220px) layout:
  - **Axes:** 7 rows, each a grid of `92px 1fr 30px`: label, 6px bar (track `#E2DDD2`, fill ink), value to 2 decimals. Order: Tension, Harshness, Aggression, Complexity, Brightness, Stability, Ambiguity.
  - **VA map:** a square, max 220px wide, with a 1px ink border, `#FBFAF7` fill, and dashed `#D6D0C4` centre lines. Axis labels: "tense" top, "calm" bottom, "dark" left, "bright" right.
    - Reference dots (6px `#BDB6A8` with 9px labels) for maj, min, maj7, 7♯9, 7♯9♯5, dim7, cluster, quartal.
    - The current chord is a 14px accent dot with a 3px paper ring and a 1px accent outline.
    - Position: `x = 8 + valence·84 %`, `y = 92 − arousal·84 %`.

### 06 Waveform
- **Stats row:** 4 blocks, each an 11px muted label over a Source Serif 28px value:
  - Harmonic ratio (just) — "10 : 15 : 16 : 24"
  - Common fundamental — "13.08 Hz"
  - Period T — "76.5 ms" (2 decimals if under 10 ms)
  - Bass cycles per T — "10 × C3"
- On the right, two segmented toggles: tuning (Just | 12-TET) and window (1T | 2T | 4T).
- **Plot:** full width, `#FBFAF7` fill, 1px `#D6D0C4` border. Height = `n·28 + 160 + 54` px.
  - A left margin of 120px holds the labels ("E♭4  314.0 Hz", 10px mono ink).
  - One lane per note, highest note on top. Each lane is 28px, with a baseline in `#E2DDD2` and a sine drawn at amplitude `0.36·lane` in ink at 75% opacity.
  - **Sum** lane: 160px tall, labelled "sum". It plots `Σ sin(2π f t) / n · 0.46·160`, drawn in the accent at 1.6px.
  - Dashed vertical lines (`3 4` pattern, ink at 40% opacity) at every k·T, labelled "0", "T = 76.5 ms", "2T = …" along the bottom.
  - The time span is `T·window`, capped at 250 ms. When capped, add " View capped at 250 ms." to the caption.
- **Caption** (muted, max 80ch):
  - Just: "Just intonation: every note is an integer multiple of the common fundamental, so the sum repeats exactly at each dashed line."
  - 12-TET: "12-TET: ratios are irrational, so the sum never repeats exactly. Dashed lines mark the just period it approximates; the drift is the cents column in 03."

### Segmented toggle (shared component)
A flex row with a 1px ink border, radius 2px, clipped overflow, `flex-shrink:0`. Each button is 12px mono, `padding 5px 10px`, borderless, `nowrap`. The selected button is ink-filled with `#F5F3EE` text; the others are transparent with ink text.

## Interactions & behaviour
- **Key click:** toggles that MIDI note. Notes are deduplicated and sorted ascending. Any key change resets the selected reading to the best reading and rewrites the text field, e.g. "C3 G3 Ab3 Eb4" (ASCII b/#).
- **Text input:**
  - Tokens are split on whitespace, commas, – or —. Each must match `^([A-Ga-g])([#b♯♭]*)(-?\d)?$`.
  - With an octave: `midi = (oct+1)·12 + pc`.
  - Without an octave: the first note goes in octave 3 (MIDI 48–59). Each later note takes the lowest MIDI value above the previous note.
  - Invalid tokens are ignored.
- **Preset click:** sets the notes.
- **Reading click:** sets `selected_root`. Only section 03 changes (the header keeps the best reading).
- **Tone model:** affects roughness (sections 04 and 05), the audio timbre and the reference dots. It does not affect the waveform.
- **Tuning:** affects the waveform frequencies, the Hz column, roughness and audio.
- **Play:** all notes start together. Envelope: 0.0001→1 over 20 ms (exponential), →0.001 by 3 s. Master gain is `0.35/√n`. "6 partials" timbre uses harmonics k=1..6 with amplitude `0.88^(k−1)/k`.
- **Arpeggiate:** the same, with note i starting at +0.32·i s.
- **Responsive:** the analysis grid collapses to one column below about 1100px, the tables scroll horizontally, and the plot redraws at the container width (use a resize observer).
- **Hover:** outline buttons and reading rows get `#EBE6DC`. There are no animations.

## State
```rust
struct AppState {
  notes: Vec<u8>,                 // sorted, unique MIDI; default [48,55,56,63]
  text: String,                   // input field buffer
  selected_root: Option<u8>,      // None = best reading
  tuning: Tuning,                 // Just (default) | Et
  timbre: Timbre,                 // Sine | Harmonic6 (default)
  window_periods: u8,             // 1 | 2 (default) | 4
}
struct Options { spelling: Spelling /*Flats default*/, ratio_limit: Limit /*Five default*/, a4: f64 /*440*/ }
```
In the prototype, `Options` are settings (Tweaks). Expose them as a small settings popover or a config file:
- ratio set: 5-limit | 7-limit
- A4: 415–466 Hz
- spelling: flats | sharps

## Design tokens
Colours:
- `--paper` #F5F3EE: page background
- `--paper-hi` #FBFAF7: inputs, keys, plot
- `--ink` #1D1B18: text, rules, fills
- `--ink-2` #4A463F: tag explanations
- `--muted` #6B665E: labels, captions
- `--muted-2` #9A9488: key labels, diagonal dot
- `--muted-3` #8F897D: reference-dot labels
- `--line` #D6D0C4: section rules, plot border
- `--line-2` #E2DDD2: row rules, bar tracks, lane baselines
- `--key-line` #BDB6A8: key borders, chip borders, reference dots
- `--sel` #EBE6DC: selected/hover rows, matrix headers
- `--diag` #ECE8E0: matrix diagonal
- `--accent` `oklch(0.56 0.16 35)` (≈ #C0502F): active keys, Play button, probability bars, sum wave, VA dot
- Roughness ramp: `oklch(0.97−0.35r 0.02+0.12r 35)` for r ∈ [0,1]

Typography:
- **Source Serif 4** (400, 600, italic 400) for chord names, degrees, tag words and stat values.
- **IBM Plex Mono** (400, 500) for everything else. Base size is 13px with line-height 1.5; numbers use tabular numerals.
- Sizes: 80/44 (chord name, clamp), 28, 26, 22, 21, 17, 15, 13, 12, 11, 10, 9.

Spacing: 2, 4, 6, 8, 10, 12, 14, 16, 20, 24, 28, 40, 48, 56. Radius: 2px (controls and cells), 3px (key bottoms), 50% (dots). No shadows, apart from the VA-dot outline ring.

## Assets
There are no images or icons. Fonts come from Google Fonts; for desktop, bundle them locally.

## Files
- `prototype/Chord Anatomy.dc.html`: working prototype; the logic lives in its `<script data-dc-script>` block.
- `prototype/support.js`: runtime needed to open the prototype.
- `ANALYSIS.md`: formal algorithm spec and test vectors.
- `screenshots/`:
  - `01-header-voicing`, `02-readings-intervals`, `03-matrix-character`, `04-waveform-just`: C–G–A♭–E♭ default
  - `05`/`06`: C7♯9
  - `07`: C7♯9♯5 matrix and character
  - `08`: C7♯9♯5 waveform in 12-TET
- The screenshots were taken at about 910px wide, so the analysis grid appears as a single column.
